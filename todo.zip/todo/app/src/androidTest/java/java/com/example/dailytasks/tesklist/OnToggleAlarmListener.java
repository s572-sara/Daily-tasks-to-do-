package com.example.dailytasks.tesklist;

import  com.example.dailytasks.model.tesk;

public interface OnToggleAlarmListener{
    void onToggle(tesk alarm);

    void onAddTask(tesk alarm);

    void onDelete(tesk alarm);
    void  onUpdate(tesk alarm);
}