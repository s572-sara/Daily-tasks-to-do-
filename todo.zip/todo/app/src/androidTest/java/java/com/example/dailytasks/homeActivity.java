package com.example.dailytasks;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.example.dailytasks.tesklist.AlarmRecyclerViewAdapter;
import com.example.dailytasks.tesklist.AlarmsListViewModel;
import com.example.dailytasks.tesklist.OnToggleAlarmListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.example.dailytasks.model.tesk;

import java.util.List;

public class homeActivity extends Fragment implements OnToggleAlarmListener {
    FloatingActionButton  fab;
    private  final int SECOND_ACTIVITY_RESULT_CODE = 0;

    private AlarmRecyclerViewAdapter alarmRecyclerViewAdapter;
    private AlarmsListViewModel alarmsListViewModel;
    private RecyclerView alarmsRecyclerView;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        alarmRecyclerViewAdapter = new AlarmRecyclerViewAdapter(this);
        alarmsListViewModel = ViewModelProviders.of(getActivity()).get(AlarmsListViewModel.class);
         alarmsListViewModel.getAlarmsLiveData().observe(getActivity(), new Observer<List<tesk>>() {
            @Override
            public void onChanged(List<tesk> alarms) {
                if (alarms != null) {
                    alarmRecyclerViewAdapter.setAlarms(alarms);
                }
            }
        });

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_home, container, false);

        fab=(FloatingActionButton) view.findViewById(R.id.fab);
       fab.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {

               Intent inten=new Intent(getActivity(),AddActivity.class);

               startActivityForResult(inten,SECOND_ACTIVITY_RESULT_CODE);

           }
       });




        alarmsRecyclerView = view.findViewById(R.id.list);
        alarmsRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        alarmsRecyclerView.setAdapter(alarmRecyclerViewAdapter);


        return view;
    }


    @Override
    public void onToggle(tesk alarm) {

    }

    @Override
    public void onAddTask(tesk alarm) {

    }

    @Override
    public void onDelete(tesk alarm) {

        alarmsListViewModel.delete(alarm);

    }

    @Override
    public void onUpdate(tesk alarm) {
        Intent inten=new Intent(getActivity(),AddActivity.class);
        inten.putExtra("Id",alarm.getId());
        inten.putExtra("time",alarm.getTime());
        inten.putExtra("date",alarm.getDate());
        inten.putExtra("title",alarm.getTitle());

        startActivityForResult(inten,SECOND_ACTIVITY_RESULT_CODE);
    }
}