package com.example.dailytasks.manage;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.dailytasks.model.tesk;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class manage {
LiveData<List<tesk>> tesks;

private  Context context;

private  String keylist="listKey";
private final  String SharedTodo="SharedTODO";

private   final  String TAG="Tage";
public  manage(Context context){
    this.context = context;
   Tesks=getAllTaskS();
}

public MutableLiveData<List<tesk>> Tesks;
//public LiveData<List<tesk>> getTesks(){
//
//  return  Tesks;
//
//}


public int  register(List<tesk> teskitem) {


        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = sharedPreferences.edit();
//        if( sharedPreferences.contains(keylist) ) {
//            Set<String> set = sharedPreferences.getStringSet(keylist, null);
//            if( set != null && !set.isEmpty() ) {
//                set.add(Integer.toString(teskitem.getId()));
//            }
//        } else {
//            Set<String> set = new HashSet<>();
//            set.add(Integer.toString(teskitem.getId()));
//            editor.putStringSet(keylist, set);
//            editor.apply();
//        }

    List<String> jsonArray=new ArrayList<>();
    for(tesk ts:teskitem) {
        JSONObject jsonObject = new JSONObject();
        try {

            jsonObject.put("id", ts.getId());
            jsonObject.put("title", ts.getTitle());
            jsonObject.put("date", ts.getDate());
            jsonObject.put("time", ts.getTime());

            jsonArray.add(jsonObject.toString());



        } catch (JSONException e) {

        }
    }

       editor.putStringSet(keylist,  new HashSet<>(jsonArray)).apply();

       Log.d(TAG, "register: "+sharedPreferences.getStringSet(keylist,new HashSet<String>()));
        return 1;
    }
 public  Set<String> getAllRegistrationIds(Context context) {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        return sharedPreferences.getStringSet(keylist, new HashSet<String>());


    }

public MutableLiveData<List<tesk>>  getAllTaskS()
  {
      MutableLiveData<List<tesk>>  tesks1= new  MutableLiveData<List<tesk>>();
      Log.d(TAG,"HI");
      Set<String> vals=getAllRegistrationIds(context);
      if (vals!=null && vals.size()>0) {


          Log.d(TAG,"vals  "+vals.size());
         Object[] list =   vals.toArray();
            List<tesk> tesks1s=new ArrayList<>();
          Log.d(TAG,"list  "+list.length);
          for (int i=0; i< list.length;i++) {
              Object item=list[i];
              try {
                  tesk tes = new tesk();
                  JSONObject jsonObject = new JSONObject(item.toString());
                  tes.setId(jsonObject.getInt("id"));
                  tes.setTitle(jsonObject.getString("title"));
                  tes.setTime(jsonObject.getString("time"));
                  tes.setDate(jsonObject.getString("date"));
                  Log.d(TAG,"vals  "+jsonObject.toString());
                  tesks1s.add(tes);
              } catch (JSONException e) {
                  e.getStackTrace();
                  Log.d(TAG,"valsError "+e.getMessage());
              }
          }

           Collections.sort(tesks1s);
          tesks1.setValue(tesks1s);
      }


      return tesks1;

  }



  public int insert(tesk alarm){
              List<tesk> tesks=
       Tesks.getValue()!=null?Tesks.getValue():new ArrayList<tesk>();
        Log.d("TAG", "insert:Liste "+tesks.size());
        tesks.add(alarm);
      Tesks.setValue(tesks);
//
//
//  //  return 1;
        return  register(tesks);
  }
  public void update(tesk alarm) {
    List<tesk> tesks1=
      Tesks.getValue();

      tesks1.set(alarm.getId(),alarm);
      Tesks.setValue(tesks1);
      register(tesks1);

    }


   public void delete(tesk alarm) {

       List<tesk> tesks1=
               Tesks.getValue();


       tesks1.remove(alarm);

       Tesks.setValue(tesks1);

       register(tesks1);

    }


}
