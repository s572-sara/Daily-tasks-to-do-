package com.example.dailytasks.tesklist;

import android.util.Log;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.dailytasks.model.tesk;
import com.example.dailytasks.R;

public class AlarmViewHolder extends RecyclerView.ViewHolder {
    private TextView alarmTime;
    private ImageView alarmRecurring;
    private TextView alarmRecurringDays;
    private TextView alarmTitle;
    private ImageButton btnDele;

    private ImageButton btnEdite;


 //   Switch alarmStarted;
    private OnToggleAlarmListener listener;

    public AlarmViewHolder(@NonNull View itemView,OnToggleAlarmListener listener) {
        super(itemView);

        alarmTime = itemView.findViewById(R.id.item_alarm_time);
        alarmRecurringDays = itemView.findViewById(R.id.item_alarm_recurringDays);
        alarmTitle = itemView.findViewById(R.id.item_alarm_title);
        btnDele=itemView.findViewById(R.id.ondelete);
        btnEdite=itemView.findViewById(R.id.onUpdate);
        this.listener = listener;
    }

    public void bind(final tesk alarm) {
        String alarmText =alarm.getTime();// String.format("%02d", alarm.getTime());

        alarmTime.setText(alarmText);
//        alarmStarted.setChecked(alarm.isStarted());

        if (alarm.getDate().length()!=0) {

            alarmRecurringDays.setText(alarm.getDate());
        }

        if (alarm.getTitle().length() != 0) {
            alarmTitle.setText( alarm.getTitle());
        }

//        alarmStarted.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
//            @Override
//            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
//                listener.onToggle(alarm);
//            }
//        });

        btnEdite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onUpdate(alarm);
            }
        });

        btnDele.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onDelete(alarm);
            }
        });
    }
}
