package com.example.dailytasks.tesklist;

import android.app.Application;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.dailytasks.model.tesk;
import com.example.dailytasks.manage.manage;

import java.util.ArrayList;
import java.util.List;

public class AlarmsListViewModel extends AndroidViewModel {
 LiveData<List<tesk>> alarmsLiveData;
manage alarmRepository;
    public AlarmsListViewModel(@NonNull Application application) {
        super(application);

        alarmRepository = new manage(application);
        alarmsLiveData = alarmRepository.Tesks;
    }

    public void update(tesk alarm) {

//        List<tesk> tesks=
//                alarmsLiveData.getValue()!=null?alarmsLiveData.getValue():new ArrayList<tesk>();
//        Log.d("TAG", "insert:Liste "+tesks.size());
//        tesks.set(alarm.getId(),alarm);
//
//          alarmRepository.register(tesks);
        alarmRepository.update(alarm);
    }


    public void delete(tesk alarm) {
        alarmRepository.delete(alarm);

        Log.d("TAG", "delete: "+alarmsLiveData.getValue().size());
    }

    public int insert(tesk alarm){

//        List<tesk> tesks=
//       alarmsLiveData.getValue()!=null?alarmsLiveData.getValue():new ArrayList<tesk>();
//        Log.d("TAG", "insert:Liste "+tesks.size());
//        tesks.add(alarm);
//
//
//  //  return 1;
//        return  alarmRepository.register(tesks);

        return alarmRepository.insert(alarm);
    }

    public LiveData<List<tesk>> getAlarmsLiveData() {
        return alarmsLiveData;
    }
}
