package com.example.dailytasks;


import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class AddActivity extends AppCompatActivity {
EditText tvTimer,task;
EditText etData;
int id=-1;
int tHour,tMinute;
DatePickerDialog.OnDateSetListener setListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        task=findViewById(R.id.task);
        tvTimer=findViewById(R.id.tv_timer);
        etData=findViewById(R.id.et_date);

        if(getIntent().hasExtra("Id"))
        {
           id=   getIntent().getIntExtra("Id",-1);
           tvTimer.setText(getIntent().getStringExtra("time"));
            etData.setText(getIntent().getStringExtra("date"));
            task.setText(getIntent().getStringExtra("title"));
        }



        Calendar calendar =Calendar.getInstance();
        final int year = calendar.get(Calendar.YEAR);
        final int month = calendar.get(Calendar.MONTH);
        final int day = calendar.get(Calendar.DAY_OF_MONTH);

        etData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog datePickerDialog =new DatePickerDialog(
                        AddActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int day) {
                     month=month+1;
                     String data = day+"/"+month+"/"+year;
                     etData.setText(data);

                    }
                },year,month,day);
                datePickerDialog.show();
            }
        });

        tvTimer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TimePickerDialog timePickerDialog= new TimePickerDialog(AddActivity.this,
                        new TimePickerDialog.OnTimeSetListener() {
                            @Override
                            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                                tHour=hourOfDay;
                                tMinute=minute;
                                Calendar calendar=Calendar.getInstance();

                                calendar.set(0,0,0,tHour,tMinute);
                                tvTimer.setText(DateFormat.format("hh:mm aa",calendar));
                            }
                        },12,0,false
                );
                timePickerDialog.updateTime(tHour,tMinute);
                timePickerDialog.show();
            }
        });
    }

    public void SaveTask(View view) {

     if(task.getText().toString().length()>0)
      {
          Intent intent = new Intent();
          if(id>=0)
              intent.putExtra("Id",id );
          intent.putExtra("title",task.getText().toString() );

          intent.putExtra("time",tvTimer.getText().toString() );
          intent.putExtra("date",etData.getText().toString() );
          setResult(RESULT_OK, intent);
          finish();
      }


    }
}