package com.example.dailytasks.model;

public class tesk implements Comparable<tesk >{
   private  int id;
   private String title;
   private   String date;
   private String time;

   public tesk(){};


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public Integer  getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public int compareTo(tesk o) {
        return this.getId().compareTo(o.getId());
    }
}
