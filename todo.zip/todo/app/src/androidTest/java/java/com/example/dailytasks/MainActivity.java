package com.example.dailytasks;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;
import com.example.dailytasks.model.tesk ;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;

import com.example.dailytasks.tesklist.AlarmsListViewModel;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {


BottomNavigationView bottomNavigationView;
    private  final int SECOND_ACTIVITY_RESULT_CODE = 0;
    AlarmsListViewModel taskViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        taskViewModel = ViewModelProviders.of(this).get(AlarmsListViewModel.class);
        bottomNavigationView=findViewById(R.id.boottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.home);

        if (savedInstanceState==null){
            getSupportFragmentManager().beginTransaction().replace(R.id.frame,new homeActivity()).commit();
        }


        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                Fragment fragment=null;
                switch (menuItem.getItemId()){
                    case R.id.daily:
                        fragment = new dailyActivity();
                       // Log.d("Tag", "onNavigationItemSelected: "+taskViewModel.getAlarmsLiveData().getValue().size());
                        break;

                    case R.id.home:
                        fragment = new homeActivity();
                        break;

                    case R.id.task:
                        fragment = new tasksActivity();
                        break;

                }
                getSupportFragmentManager().beginTransaction().replace(R.id.frame,fragment).commit();

                return true;
            }
        });

    }




    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d("TAG", "register: "+requestCode);
        // check that it is the SecondActivity with an OK result
    //  if (requestCode == 0 ) {

            Log.d("TAG", "register: requestCode "+requestCode);
            if (resultCode == RESULT_OK) {
                Log.d("TAG", "register: "+requestCode);
                // get String data from Intent
                String title = data.getStringExtra("title");
                String date = data.getStringExtra("date");
                String time= data.getStringExtra("time");
                int id=taskViewModel.getAlarmsLiveData().getValue()==null?0:taskViewModel.getAlarmsLiveData().getValue().size();

                Log.d("TAG", "id: "+id);
                if(data.hasExtra("Id"))
                    id=data.getIntExtra("Id",id);

                tesk tes=new tesk();
                tes.setId(id);
                //tes.setId(taskViewModel.getAlarmsLiveData().getValue()==null?0:taskViewModel.getAlarmsLiveData().getValue().size());
                tes.setTitle(title);
                tes.setDate(date);
                tes.setTime(time);
                if(data.hasExtra("Id"))
                    taskViewModel.update(tes);
                else
                taskViewModel.insert(tes);

                getSupportFragmentManager().beginTransaction().replace(R.id.frame,new homeActivity()).commit();

            }
       // }
    }
}